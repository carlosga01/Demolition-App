//
//  CustomPointAnnotation.swift
//  Demolition
//
//  Created by Carlos Garcia on 5/13/18.
//  Copyright © 2018 6.S062 Project. All rights reserved.
//

import Foundation
import MapKit

class CustomPointAnnotation: MKPointAnnotation {
    var imageName: String!
}
